package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Yuding;

import org.springframework.stereotype.Repository;


@Repository
public interface YudingMapper extends MapperBase<Yuding> {
}
