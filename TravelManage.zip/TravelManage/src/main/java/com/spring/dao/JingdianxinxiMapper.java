package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Jingdianxinxi;

import org.springframework.stereotype.Repository;


@Repository
public interface JingdianxinxiMapper extends MapperBase<Jingdianxinxi> {
}
