package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Lvyouxianlu;

import org.springframework.stereotype.Repository;


@Repository
public interface LvyouxianluMapper extends MapperBase<Lvyouxianlu> {
}
