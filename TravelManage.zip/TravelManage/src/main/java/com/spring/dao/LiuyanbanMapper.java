package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Liuyanban;

import org.springframework.stereotype.Repository;


@Repository
public interface LiuyanbanMapper extends MapperBase<Liuyanban> {
}
