package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Xinwenfenlei;

import org.springframework.stereotype.Repository;


@Repository
public interface XinwenfenleiMapper extends MapperBase<Xinwenfenlei> {
}
