package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Meishifenlei;

import org.springframework.stereotype.Repository;


@Repository
public interface MeishifenleiMapper extends MapperBase<Meishifenlei> {
}
