package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Difangmeishi;

import org.springframework.stereotype.Repository;


@Repository
public interface DifangmeishiMapper extends MapperBase<Difangmeishi> {
}
