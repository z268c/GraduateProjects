package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Meishifenlei;

public interface MeishifenleiService extends IServiceBase<Meishifenlei> {
}
