package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Yuding;

public interface YudingService extends IServiceBase<Yuding> {
}
