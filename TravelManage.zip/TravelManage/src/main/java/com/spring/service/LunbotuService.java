package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Lunbotu;

public interface LunbotuService extends IServiceBase<Lunbotu> {
}
