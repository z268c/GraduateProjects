package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Jingdianxinxi;

public interface JingdianxinxiService extends IServiceBase<Jingdianxinxi> {
}
