package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Xinwenfenlei;

public interface XinwenfenleiService extends IServiceBase<Xinwenfenlei> {
}
