package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Difangmeishi;

public interface DifangmeishiService extends IServiceBase<Difangmeishi> {
}
