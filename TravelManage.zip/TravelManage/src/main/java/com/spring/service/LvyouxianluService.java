package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Lvyouxianlu;

public interface LvyouxianluService extends IServiceBase<Lvyouxianlu> {
}
