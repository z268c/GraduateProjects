package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Xinwenxinxi;

public interface XinwenxinxiService extends IServiceBase<Xinwenxinxi> {
}
