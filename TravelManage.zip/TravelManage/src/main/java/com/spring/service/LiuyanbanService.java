package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Liuyanban;

public interface LiuyanbanService extends IServiceBase<Liuyanban> {
}
