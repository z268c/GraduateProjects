package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Shoucangjilu;
/**
 *  业务类
 */
public interface ShoucangjiluService extends IServiceBase<Shoucangjilu> {
}
