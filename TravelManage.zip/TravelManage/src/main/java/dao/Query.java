package dao;

/**
 * 继承自库中jntoo-query.jar
 */
public class Query extends net.jntoo.db.Query {
}
