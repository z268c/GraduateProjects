
module.exports = {
    proxyUrl:'http://localhost:8088',
    title:"旅游管理系统设计与实现",
}
