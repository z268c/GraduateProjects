var setting = require('./setting')

const config = {
    service_url:'',
}


export default config
