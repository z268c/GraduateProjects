// Here is a list of the toolbar
// Detail list see https://www.tinymce.com/docs/advanced/editor-control-identifiers/#toolbarcontrols

const toolbar =  "undo redo | styleselect formatselect  | fontsizeselect | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | outdent indent | link image | code | colorpicker | imagetools | | print preview media fullpage | forecolor backcolor emoticons"
export default toolbar
