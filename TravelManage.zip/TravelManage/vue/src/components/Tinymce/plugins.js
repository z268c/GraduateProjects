// Any plugins you want to use has to be imported
// Detail plugins list see https://www.tinymce.com/docs/plugins/
// Custom builds see https://www.tinymce.com/download/custom-builds/

const plugins = [
    "advlist autolink lists link charmap print preview anchor "+
    "searchreplace visualblocks code fullscreen "+
    "insertdatetime media table contextmenu pasteword wordcount "+
    "code image imagetools colorpicker charmap emoticons imagetools"
]
export default plugins
