import imageToggle from "./image-toggle";


function install(Vue) {
    Vue.component(imageToggle.name , imageToggle);
}

export default {
    install
}
