<template>

</template>
<style type="text/scss" lang="scss">
@import "./asset/icon/MKPlayer.scss";
</style>
<script>
    export default {
        name: "e-play-list",
        data() {
            return {}
        },
        watch: {},
        computed: {},
        methods: {},
        created() {

        },
        mounted() {
        },
        destroyed() {
        }
    }
</script>
