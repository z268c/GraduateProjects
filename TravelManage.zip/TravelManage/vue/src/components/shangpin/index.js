import shangpinban from "./shangpinban";


function install(Vue) {
    Vue.component(shangpinban.name , shangpinban);
}

export default {
    install
}
