

export default [
        {
        label:'线路预定管理',
        to:'',
        children:[
                        {
                label:'我的预定查询',
                to:'/admin/yuding_yudingren',
            },
                    ]
    },
        {
        label:'个人中心',
        to:'',
        children:[
                        {
                label:'修改个人资料',
                to:'/admin/yonghuupdtself',
            },
                        {
                label:'修改密码',
                to:'/admin/mod',
            },
                        {
                label:'我的收藏',
                to:'/admin/shoucangjilu',
            },
                        {
                label:'我的留言',
                to:'/admin/liuyanban_liuyanren',
            },
                    ]
    },
    ]
