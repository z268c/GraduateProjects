
import guanliyuan from './guanliyuan';

import yonghu from './yonghu';


export default {

    "管理员":guanliyuan,
    "用户":yonghu,

}

