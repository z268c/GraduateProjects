<template>
    <e-container>
        <Add></Add>
    </e-container>
</template>
<style type="text/scss" lang="scss">

</style>
<script>
    import Add from './add'
    export default {
        components:{
            'Add':Add
        },
    }
</script>
